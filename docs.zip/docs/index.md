---

layout: default

---

# Hi, I'm YOUR NAME HERE

This is my site of projects for the [Lede Program](http://ledeprogram.com)

* [Project 1]({{ site.url }}/a-very-cool-project): Lorem ipsum
* [Project 2]({{ site.url }}/a-very-cool-project): Lorem ipsum
* [Project 3]({{ site.url }}/a-very-cool-project): Lorem ipsum